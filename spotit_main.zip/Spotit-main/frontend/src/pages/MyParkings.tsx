import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/auth-context';
import AppLayout from '../components/layout/AppLayout';
import ParkingForm from '../components/parking/ParkingForm';
import Alert from '../components/ui/Alert';
import Button from '../components/ui/Button';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import Spinner from '../components/ui/Spinner';
import {
  deleteParking,
  getMyParkings,
  getParkingErrorMessage,
  toggleParking,
} from '../services/parkingApi';
import type { Parking } from '../types/parking';
import { formatINR } from '../utils/format';
import { notifyError, notifySuccess } from '../utils/notify';

type FormMode = 'create' | 'edit' | null;

export default function MyParkings() {
  const navigate = useNavigate();
  const { user, openAuthModal } = useAuth();
  const [parkings, setParkings] = useState<Parking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [formMode, setFormMode] = useState<FormMode>(null);
  const [editingParking, setEditingParking] = useState<Parking | undefined>();
  const [deleteTarget, setDeleteTarget] = useState<Parking | null>(null);
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    let active = true;

    getMyParkings()
      .then((data) => {
        if (active) setParkings(data);
      })
      .catch((err) => {
        if (active) setError(getParkingErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [user]);

  const openCreateForm = () => {
    // Creating a lot requires pinning it on the map, which only /explore can do.
    navigate('/explore?addParking=1');
  };

  const openEditForm = (parking: Parking) => {
    setActionError(null);
    setEditingParking(parking);
    setFormMode('edit');
  };

  const closeForm = () => {
    setFormMode(null);
    setEditingParking(undefined);
  };

  const handleSaved = (parking: Parking) => {
    if (formMode === 'create') {
      setParkings((current) => [parking, ...current]);
      notifySuccess('Parking lot created successfully.');
    } else {
      setParkings((current) =>
        current.map((item) => (item.id === parking.id ? parking : item)),
      );
      notifySuccess('Parking lot updated successfully.');
    }
    closeForm();
  };

  const handleToggleStatus = async (parking: Parking) => {
    setActionError(null);
    setTogglingId(parking.id);

    try {
      const updated = await toggleParking(parking.id, !parking.isActive);
      setParkings((current) =>
        current.map((item) => (item.id === updated.id ? updated : item)),
      );
      notifySuccess(
        updated.isActive ? 'Parking lot activated.' : 'Parking lot deactivated.',
      );
    } catch (err) {
      const message = getParkingErrorMessage(err);
      setActionError(message);
      notifyError(message);
    } finally {
      setTogglingId(null);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;

    setActionError(null);
    setDeletingId(deleteTarget.id);

    try {
      await deleteParking(deleteTarget.id);
      setParkings((current) => current.filter((item) => item.id !== deleteTarget.id));
      notifySuccess('Parking lot deleted.');
      setDeleteTarget(null);
    } catch (err) {
      const message = getParkingErrorMessage(err);
      setActionError(message);
      notifyError(message);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <AppLayout>
      <main className="mx-auto max-w-5xl px-4 pt-6 pb-24 sm:px-6 md:pb-8">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[var(--pm-color-text)]">My Parkings</h1>
            <p className="mt-1 text-sm text-[var(--pm-color-muted)]">
              Create and manage the parking lots you own.
            </p>
          </div>
          {!formMode && parkings.length > 0 && (
            <Button type="button" className="sm:w-auto" onClick={openCreateForm}>
              Add parking
            </Button>
          )}
        </div>

        {actionError && (
          <div className="mb-5">
            <Alert variant="error" message={actionError} />
          </div>
        )}

        {formMode && (
          <div className="mb-6">
            <ParkingForm
              key={formMode === 'create' ? 'create' : editingParking?.id}
              mode={formMode}
              initialValues={editingParking}
              onSaved={handleSaved}
              onCancel={closeForm}
            />
          </div>
        )}

        {!user ? (
          <div className="mt-8 rounded-3xl border border-slate-200 bg-white p-8 sm:p-12 shadow-sm text-center max-w-lg mx-auto">
            <h2 className="text-xl font-bold text-slate-900">Sign in to manage your parking spaces</h2>
            <p className="mt-2 text-sm text-slate-600 max-w-sm mx-auto leading-relaxed">
              List parking spots, set hourly/monthly rates, and track occupancy and earnings.
            </p>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => openAuthModal({ title: 'Sign in to Manage Parkings' })}
                className="w-full sm:w-auto rounded-xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white shadow-md hover:bg-emerald-700 active:scale-[0.99] transition-all"
              >
                Sign In / Register
              </button>
              <Link
                to="/explore"
                className="w-full sm:w-auto rounded-xl border border-slate-200 bg-slate-50 px-6 py-3 text-sm font-bold text-slate-700 hover:bg-slate-100 transition-all text-center"
              >
                Explore Map
              </Link>
            </div>
          </div>
        ) : loading ? (
          <div className="flex items-center justify-center py-24">
            <Spinner className="h-8 w-8 text-emerald-600" />
          </div>
        ) : error ? (
          <Alert variant="error" message={error} />
        ) : parkings.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-[var(--pm-color-border-strong)] bg-[var(--pm-color-surface)] p-10 text-center">
            <h2 className="text-lg font-semibold text-[var(--pm-color-text)]">No parking lots yet</h2>
            <p className="mt-2 text-sm text-[var(--pm-color-muted)]">
              Add your first parking lot to start accepting bookings.
            </p>
            {!formMode && (
              <Button type="button" className="mx-auto mt-6 sm:w-auto" onClick={openCreateForm}>
                Add parking
              </Button>
            )}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {parkings.map((parking) => (
              <article
                key={parking.id}
                className="flex flex-col rounded-2xl bg-[var(--pm-color-surface)] p-5 shadow-sm ring-1 ring-[var(--pm-color-border)]"
              >
                {parking.photos?.[0] && (
                  <div className="-mx-5 -mt-5 mb-4 aspect-video overflow-hidden rounded-t-2xl bg-[var(--pm-color-surface-raised)]">
                    <img
                      src={parking.photos[0]}
                      alt={parking.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                )}

                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-bold text-[var(--pm-color-text)]">{parking.name}</h2>
                    <p className="mt-1 text-sm text-[var(--pm-color-muted)]">{parking.address}</p>
                  </div>
                  <span
                    className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                      parking.isActive
                        ? 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200'
                        : 'bg-[var(--pm-color-surface-raised)] text-[var(--pm-color-muted)] ring-1 ring-[var(--pm-color-border)]'
                    }`}
                  >
                    {parking.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>

                {parking.description && (
                  <p className="mt-3 text-sm text-[var(--pm-color-muted)]">{parking.description}</p>
                )}

                <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <dt className="text-[var(--pm-color-muted)]">Price / hour</dt>
                    <dd className="font-semibold text-[var(--pm-color-text)]">
                      {formatINR(parking.pricePerHour)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[var(--pm-color-muted)]">Availability</dt>
                    <dd className="font-semibold text-[var(--pm-color-text)]">
                      {parking.availableSlots} / {parking.totalSlots}
                    </dd>
                  </div>
                </dl>

                <div className="mt-5 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => openEditForm(parking)}
                    className="rounded-lg border border-[var(--pm-color-border)] bg-[var(--pm-color-surface)] px-3 py-2 text-sm font-semibold text-[var(--pm-color-text)] transition-colors hover:bg-[var(--pm-color-surface-raised)] focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    Edit
                  </button>
                  <Button
                    type="button"
                    variant="secondary"
                    className="w-auto px-3 py-2"
                    loading={togglingId === parking.id}
                    onClick={() => handleToggleStatus(parking)}
                  >
                    {parking.isActive ? 'Deactivate' : 'Activate'}
                  </Button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(parking)}
                    className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm font-semibold text-red-700 transition-colors hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    Delete
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>

      {deleteTarget && (
        <ConfirmDialog
          title="Delete parking lot"
          message={`Are you sure you want to delete "${deleteTarget.name}"? This action cannot be undone.`}
          confirmLabel="Delete"
          loading={deletingId === deleteTarget.id}
          onConfirm={handleDelete}
          onCancel={() => {
            if (!deletingId) setDeleteTarget(null);
          }}
        />
      )}
    </AppLayout>
  );
}
