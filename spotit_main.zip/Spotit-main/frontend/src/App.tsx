import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import GuestRoute from './components/GuestRoute';
import Auth from './pages/Auth';
import Home from './pages/Home';
import ParkingDetails from './pages/ParkingDetails';
import BookingConfirm from './pages/BookingConfirm';
import Bookings from './pages/Bookings';
import MyVehicles from './pages/MyVehicles';
import AIVerification from './pages/AIVerification';
import MyParkings from './pages/MyParkings';
import OwnerDashboard from './pages/OwnerDashboard';
import Explore from './pages/Explore';
import Account from './pages/Account';
import AdminLayout from './components/admin/AdminLayout';
import AdminOverview from './pages/admin/AdminOverview';
import AdminComplaints from './pages/admin/AdminComplaints';
import AdminComplaintDetails from './pages/admin/AdminComplaintDetails';
import AdminBookings from './pages/admin/AdminBookings';
import ReassignmentOfferMount from './components/reassignment/ReassignmentOfferMount';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route
            path="/login"
            element={
              <GuestRoute>
                <Auth defaultMode="login" />
              </GuestRoute>
            }
          />
          <Route
            path="/register"
            element={
              <GuestRoute>
                <Auth defaultMode="register" />
              </GuestRoute>
            }
          />
          <Route
            path="/"
            element={
              <Home />
            }
          />
          <Route
            path="/explore"
            element={
              <Explore />
            }
          />
          <Route
            path="/parking/:id"
            element={
              <ParkingDetails />
            }
          />
          <Route
            path="/booking/confirm/:id"
            element={
              <ProtectedRoute>
                <BookingConfirm />
              </ProtectedRoute>
            }
          />
          <Route
            path="/bookings"
            element={
              <Bookings />
            }
          />
          <Route
            path="/my-parkings"
            element={
              <MyParkings />
            }
          />
          <Route
            path="/my-vehicles"
            element={
              <MyVehicles />
            }
          />
          <Route
            path="/account"
            element={
              <ProtectedRoute>
                <Account />
              </ProtectedRoute>
            }
          />
          <Route
            path="/verification"
            element={
              <AIVerification />
            }
          />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute allowedRoles={['OWNER', 'ADMIN']}>
                <OwnerDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin"
            element={
              <ProtectedRoute allowedRoles={['ADMIN']}>
                <AdminLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Navigate to="/admin/dashboard" replace />} />
            <Route path="dashboard" element={<AdminOverview />} />
            <Route path="complaints" element={<AdminComplaints />} />
            <Route path="complaints/:id" element={<AdminComplaintDetails />} />
            <Route path="bookings" element={<AdminBookings />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        <ReassignmentOfferMount />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              fontSize: '14px',
              fontWeight: 500,
              borderRadius: '10px',
            },
            success: {
              iconTheme: { primary: '#16a34a', secondary: '#fff' },
            },
            error: {
              duration: 5000,
            },
          }}
        />
      </AuthProvider>
    </BrowserRouter>
  );
}