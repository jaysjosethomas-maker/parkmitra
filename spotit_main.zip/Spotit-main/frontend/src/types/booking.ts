import type { ParkingLot } from './parking';
import type { VehicleType } from './vehicle';

/**
 * RESERVED is the "space is held for you" state (the Continuity Engine spec
 * calls it CONFIRMED). DISPUTED means the user reported that the lot failed
 * them: the booking is frozen as evidence rather than cancelled.
 */
export type BookingStatus =
  | 'RESERVED'
  | 'ACTIVE'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'EXPIRED'
  | 'DISPUTED'
  /**
   * Auto-Reassignment: a candidate booking the engine automatically held on
   * another lot, awaiting the user's accept/decline (or the 5-minute
   * auto-accept). Deliberately absent from every Bookings-page tab -- the
   * user interacts with it through the app-wide offer popup, not a list card.
   */
  | 'PENDING_REASSIGNMENT';

/**
 * Snapshot of the vehicle at the time the booking was created. Old bookings
 * (created before the vehicle library existed) have `id: null` and an empty
 * `imageUrl`, so the UI must render a placeholder for that legacy state.
 */
export interface BookingVehicle {
  id: string | null;
  registration: string;
  type: VehicleType;
  imageUrl: string;
  make: string | null;
  model: string | null;
  color: string | null;
}

/**
 * At most one of these is ever set for a given booking -- it's either
 * someone's cancelled original (role ORIGINAL) or someone's held candidate
 * (role CANDIDATE), never both.
 */
export interface BookingReassignmentSummary {
  id: string;
  status: 'PENDING' | 'ACCEPTED' | 'AUTO_ACCEPTED' | 'DECLINED';
  role: 'ORIGINAL' | 'CANDIDATE';
  decisionDeadline: string | null;
  linkedBookingId: string | null;
}

export interface Booking {
  id: string;
  userId: string;
  parkingLotId: string;
  vehicleNumber: string;
  durationMinutes: number;
  reservedAt: string;
  checkInDeadline: string;
  checkInTime: string | null;
  sessionEndsAt: string | null;
  checkOutTime: string | null;
  estimatedAmount: number;
  finalAmount: number | null;
  status: BookingStatus;
  cancellationReason: string | null;
  cancelledAt: string | null;
  disputedAt: string | null;
  lastLocationAt: string | null;
  lastSeenAt: string | null;
  createdAt: string;
  updatedAt: string;
  parkingLot: ParkingLot;
  vehicle: BookingVehicle;
  payment?: {
    razorpayPaymentId: string;
    razorpayOrderId: string;
    amount: number;
    status: string;
  };
  reassignment?: BookingReassignmentSummary | null;
}
